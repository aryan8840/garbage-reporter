const express = require('express');
const cors = require('cors');
const multer = require('multer');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

let reports = [];
let sweepers = [
  { id: 1, name: 'Ravi', lat: 28.6139, lng: 77.2090, points: 0 },
  { id: 2, name: 'Sita', lat: 28.6140, lng: 77.2100, points: 0 }
];

const storage = multer.memoryStorage();
const upload = multer({ storage });

function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

app.post('/upload', upload.single('image'), (req, res) => {
  const { lat, lng, description } = req.body;
  const imageBuffer = req.file.buffer.toString('base64');

  let nearest = null;
  let minDist = Infinity;
  sweepers.forEach(sweeper => {
    const dist = getDistance(lat, lng, sweeper.lat, sweeper.lng);
    if (dist < minDist) {
      minDist = dist;
      nearest = sweeper;
    }
  });

  reports.push({ image: imageBuffer, lat, lng, description, sweeperId: nearest.id });
  console.log(`Notification sent to ${nearest.name}: New task assigned!`);
  res.json({ message: 'Report submitted successfully!', assignedTo: nearest.name });
});

app.get('/sweepers', (req, res) => {
  res.json(sweepers);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
